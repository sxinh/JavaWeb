package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utils.JDBCUtils;

@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		ServletContext context = this.getServletContext();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = JDBCUtils.getConnection();
			stmt = conn.createStatement();
			String sql = "select * from user where name = '" + username + "'";
			rs = stmt.executeQuery(sql);
			if(username.equals("BOSS") && password.equals("123456"))
			{
				response.getWriter().print("�̼ң�" + username);
				context.setAttribute("DifName", username);
				response.sendRedirect("/wlyy/ManagerComponent");
			}
			else if(!rs.next())
			{
				request.setAttribute("err", "�û���������");
				System.out.println("yi");
				request.getRequestDispatcher("/Login.jsp").forward(request, response);
			}
			else if(!(rs.getString("password").equals(password)))
			{
				request.setAttribute("err", "�������");
				System.out.println("er");
				request.getRequestDispatcher("/Login.jsp").forward(request, response);
			}
			else
			{
				response.getWriter().print("�˿ͣ�" + username);
				context.setAttribute("DifName", username);
				response.sendRedirect("/wlyy/ManagerComponent");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
