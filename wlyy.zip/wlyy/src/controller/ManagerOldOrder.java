package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.NewOrder;
import entity.OldOrder;
import utils.JDBCUtils;

@WebServlet("/ManagerOldOrder")
public class ManagerOldOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");		
		ServletContext context = this.getServletContext();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<OldOrder> list = new ArrayList<OldOrder>();
		try {
			conn = JDBCUtils.getConnection();
			stmt = conn.createStatement();
			if(String.valueOf(context.getAttribute("DifName")).equals("BOSS"))
			{
				String id = request.getParameter("id");
				if(id != null)
				{
					String sql5 = "select oldOrder.id as id,name,cid,type,pattern,brand,price,oldOrder.num as num,date from oldOrder,component where cid = component.id";
					rs = stmt.executeQuery(sql5);
					while(rs.next())
					{
						OldOrder oo = new OldOrder();
						oo.setId(rs.getString("id"));
						oo.setName(rs.getString("name"));
						oo.setCid(rs.getInt("cid"));
						oo.setType(rs.getString("type"));
						oo.setPattern(rs.getString("pattern"));
						oo.setBrand(rs.getString("brand"));
						oo.setPrice(rs.getInt("price"));
						oo.setNum(rs.getInt("num"));
						oo.setAmount(rs.getInt("price") * rs.getInt("num"));
						oo.setDate(rs.getString("date"));
						list.add(oo);
					}
					request.setAttribute("result", list);
					System.out.println("1");
					request.getRequestDispatcher("/PurchaseLog.jsp").forward(request, response);
				}
				else
				{
					String sql5 = "select id,type,pattern,brand,price,all_sale from component,(select cid,sum(num) as all_sale from oldOrder group by cid) as temp where id = cid";
					rs = stmt.executeQuery(sql5);
					while(rs.next())
					{
						OldOrder oo = new OldOrder();
						oo.setCid(rs.getInt("id"));
						oo.setType(rs.getString("type"));
						oo.setPattern(rs.getString("pattern"));
						oo.setBrand(rs.getString("brand"));
						oo.setPrice(rs.getInt("price"));
						oo.setNum(rs.getInt("all_sale"));
						oo.setAmount(rs.getInt("price") * rs.getInt("all_sale"));
						list.add(oo);
					}
					request.setAttribute("result", list);
					System.out.println("2");
					request.getRequestDispatcher("/SaleStatistics.jsp").forward(request, response);
				}
			}
			else
			{
				String sql5 = "select oldOrder.id as id,cid,type,pattern,brand,price,oldOrder.num as num,date from oldOrder,component where cid = component.id and name = '" + String.valueOf(context.getAttribute("DifName")) + "'";
				rs = stmt.executeQuery(sql5);
				while(rs.next())
				{
					OldOrder oo = new OldOrder();
					oo.setId(rs.getString("id"));
					oo.setCid(rs.getInt("cid"));
					oo.setType(rs.getString("type"));
					oo.setPattern(rs.getString("pattern"));
					oo.setBrand(rs.getString("brand"));
					oo.setPrice(rs.getInt("price"));
					oo.setNum(rs.getInt("num"));
					oo.setAmount(rs.getInt("price") * rs.getInt("num"));
					oo.setDate(rs.getString("date"));
					list.add(oo);
				}
				request.setAttribute("result", list);
				System.out.println("3");
				request.getRequestDispatcher("/HistoricalOrder.jsp").forward(request, response);
			}
	
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
