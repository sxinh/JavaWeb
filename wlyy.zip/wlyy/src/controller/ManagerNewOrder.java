package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.NewOrder;
import utils.JDBCUtils;

@WebServlet("/ManagerNewOrder")
public class ManagerNewOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");		
		ServletContext context = this.getServletContext();
		Connection conn = null;
		Statement stmt = null;
		Statement stmt2 = null;
		ResultSet rs = null;
		ArrayList<NewOrder> list = new ArrayList<NewOrder>();
		try {
			conn = JDBCUtils.getConnection();
			stmt = conn.createStatement();
			stmt2 = conn.createStatement();
			String delete = request.getParameter("delete");
			String paying = request.getParameter("paying");		
			if(delete != null)
			{
				String delete_id = request.getParameter("delete_id");
				String sql = "delete from newOrder where id = " + delete_id;
				int real_num = stmt.executeUpdate(sql);
				if(real_num > 0)
				{
					request.setAttribute("delete_re", "ɾ���ɹ���");
				}
				else
				{
					request.setAttribute("delete_re", "ɾ��ʧ�ܣ�");
				}
			}
			else if(paying != null)
			{
				int all_amount = Integer.parseInt(request.getParameter("all_amount"));
				String difName = String.valueOf(context.getAttribute("DifName"));
				String sql = "select money from user where name = '" + difName + "'";
				rs = stmt.executeQuery(sql);
				rs.next();
				int money = rs.getInt("money");
				if(money >= all_amount)
				{
					String sql2 = "select * from newOrder where name = '" + difName + "'";
					rs = stmt.executeQuery(sql2);
					while(rs.next())
					{
						System.out.println("hihihihi");
						String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
						String sql3 = "insert into oldOrder(name,cid,num,date) values('" + difName + "'," + rs.getInt("cid") + "," + rs.getInt("num") + ",'" + date + "')";
						stmt2.executeUpdate(sql3);
						String sql4 = "update component set num = num - " + rs.getInt("num") + ",sale = sale + " +  rs.getInt("num") + " where id = " + rs.getInt("cid");
						stmt2.executeUpdate(sql4);
					}
					String sql4 = "delete from newOrder where name = '" + difName + "'";
					stmt.executeUpdate(sql4);
					String sql5 = "update user set money = " + (money - all_amount) + " where name = '" + difName + "'";
					stmt.executeUpdate(sql5);
					request.setAttribute("paying_re", "����ɹ���");
				}
				else
				{
					request.setAttribute("paying_re", "���㣬����ʧ�ܣ�");
				}
			}
			String sql5 = "select newOrder.id as id,cid,type,pattern,brand,price,newOrder.num as num from newOrder,component where cid = component.id and name = '" + String.valueOf(context.getAttribute("DifName")) + "'";
			rs = stmt.executeQuery(sql5);
			int sum = 0;
			while(rs.next())
			{
				NewOrder no = new NewOrder();
				no.setId(rs.getString("id"));
				no.setCid(rs.getInt("cid"));
				no.setType(rs.getString("type"));
				no.setPattern(rs.getString("pattern"));
				no.setBrand(rs.getString("brand"));
				no.setPrice(rs.getInt("price"));
				no.setNum(rs.getInt("num"));
				no.setAmount(rs.getInt("price") * rs.getInt("num"));
				sum += no.getAmount();
				list.add(no);
			}
			if(sum == 0)
			{
				request.setAttribute("delete_re", "���ﳵΪ�գ�");
			}
			request.setAttribute("result", list);
			request.setAttribute("sum", sum);
			System.out.println("1");
			request.getRequestDispatcher("/ShoppingCart.jsp").forward(request, response);
	
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
