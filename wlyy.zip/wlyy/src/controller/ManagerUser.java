package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.User;
import utils.JDBCUtils;

@WebServlet("/ManagerUser")
public class ManagerUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		ServletContext context = this.getServletContext();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<User> list = new ArrayList<User>();
		try {
			conn = JDBCUtils.getConnection();
			stmt = conn.createStatement();
			String update = request.getParameter("update");
			if(update != null)
			{
				String name = request.getParameter("name");
				String update_password = request.getParameter("update_password");
				String update_email = request.getParameter("update_email");	
				String update_money = request.getParameter("update_money");
				String sql = "update user set password = '" + update_password + "',email = '" + update_email + "',money = " + update_money + " where name = '" + name + "'";
				int real_num = stmt.executeUpdate(sql);
				if(real_num > 0)
				{
					request.setAttribute("update_re", "�޸ĳɹ���");
				}
				else
				{
					request.setAttribute("update_re", "�޸�ʧ�ܣ�");
				}
			}					
			if(String.valueOf(context.getAttribute("DifName")).equals("BOSS"))
			{
				String sql5 = "select * from user";
				rs = stmt.executeQuery(sql5);
				while(rs.next())
				{
					User us = new User();
					us.setName(rs.getString("name"));
					us.setPassword(rs.getString("password"));
					us.setEmail(rs.getString("email"));
					us.setMoney(rs.getInt("money"));
					list.add(us);
				}
				request.setAttribute("result", list);
				System.out.println("1");
				request.getRequestDispatcher("/UserInfo.jsp").forward(request, response);
			}
			else
			{				
				String sql5 = "select * from user where name = '" + String.valueOf(context.getAttribute("DifName")) + "'";
				rs = stmt.executeQuery(sql5);
				rs.next();
				User us = new User();
				us.setName(rs.getString("name"));
				us.setPassword(rs.getString("password"));
				us.setEmail(rs.getString("email"));
				us.setMoney(rs.getInt("money"));
				request.setAttribute("result", us);
				System.out.println("2");
				request.getRequestDispatcher("/PersonInfo.jsp").forward(request, response);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
