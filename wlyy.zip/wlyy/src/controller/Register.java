package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import utils.JDBCUtils;

@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String confirm_password = request.getParameter("confirm_password");
		String email = request.getParameter("email");
		ServletContext context = this.getServletContext();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = JDBCUtils.getConnection();
			stmt = conn.createStatement();
			String sql = "select * from user where name = '" + username + "'";
			rs = stmt.executeQuery(sql);
			if(rs.next() || username.equals("BOSS"))
			{
				request.setAttribute("err", "�û����Ѵ���");
				System.out.println("yi");
				request.getRequestDispatcher("/Register.jsp").forward(request, response);
			}
			else if(!password.equals(confirm_password))
			{
				request.setAttribute("err", "������������벻ƥ��");
				System.out.println("yi");
				request.getRequestDispatcher("/Register.jsp").forward(request, response);
			}
			else
			{
				String sql2 = "insert into user(name,password,email) values('" + username +  "','" + password + "','" + email + "')";
				int real_num = stmt.executeUpdate(sql2);
				if(real_num > 0)
				{
					request.setAttribute("err", "ע��ɹ���");
					request.getRequestDispatcher("/Login.jsp").forward(request, response);
				}			
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
