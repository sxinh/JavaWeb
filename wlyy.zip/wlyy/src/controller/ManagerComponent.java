package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Component;
import utils.JDBCUtils;

@WebServlet("/ManagerComponent")
public class ManagerComponent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=utf-8");
		request.setCharacterEncoding("utf-8");		
		ServletContext context = this.getServletContext();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<Component> list = new ArrayList<Component>();
		try { 
			conn = JDBCUtils.getConnection();
			stmt = conn.createStatement();
			String add = request.getParameter("add");
			String delete = request.getParameter("delete");
			String update = request.getParameter("update");
			String buy = request.getParameter("buy");
			if(add != null)
			{	
				String add_type = request.getParameter("add_type");
				String add_pattern = request.getParameter("add_pattern");
				String add_brand = request.getParameter("add_brand");
				if(add_type.equals("") || add_pattern.equals("") || add_brand.equals("") || request.getParameter("add_price").equals(""))
				{
					request.setAttribute("add_re", "����ʧ�ܣ��ֶβ���Ϊ�գ�");
				}
				else
				{
					int add_price = Integer.parseInt(request.getParameter("add_price"));
					String sql = "insert into component (type,pattern,brand,price) values('" + add_type + "','" + add_pattern + "','" + add_brand + "'," + add_price + ")";
					int real_num = stmt.executeUpdate(sql);
					if(real_num > 0)
					{
						request.setAttribute("add_re", "���ӳɹ���");
					}
					else
					{
						request.setAttribute("add_re", "����ʧ�ܣ�");
					}
				}
			}
			else if(delete != null)
			{
				String delete_id = request.getParameter("delete_id");
				String sql = "delete from component where id = " + delete_id;
				int real_num = stmt.executeUpdate(sql);
				if(real_num > 0)
				{
					request.setAttribute("delete_re", "ɾ���ɹ���");
				}
				else
				{
					request.setAttribute("delete_re", "ɾ��ʧ�ܣ�");
				}
			}
			else if(update != null)
			{
				int update_price = Integer.parseInt(request.getParameter("update_price"));
				int update_num = Integer.parseInt(request.getParameter("update_num"));
				String delete_id = request.getParameter("delete_id");
				String sql = "update component set price = " + update_price + ",num = " + update_num + " where id = " + delete_id;
				int real_num = stmt.executeUpdate(sql);
				if(real_num > 0)
				{
					request.setAttribute("update_re", "�޸ĳɹ���");
				}
				else
				{
					request.setAttribute("update_re", "�޸�ʧ�ܣ�");
				}
			}
			else if(buy != null)
			{
				String buy_id = request.getParameter("buy_id");
				String buy_num = request.getParameter("buy_num");				
				String difName = String.valueOf(context.getAttribute("DifName"));
				String sql = "insert into newOrder(name,cid,num) values('" + difName + "'," + buy_id + "," + buy_num + ")";
				int real_num = stmt.executeUpdate(sql);
				if(real_num > 0)
				{
					request.setAttribute("buy_re", "���ӳɹ���");
				}
				else
				{
					request.setAttribute("buy_re", "����ʧ�ܣ�");
				}
			}
			String sql5 = "select * from component";
			rs = stmt.executeQuery(sql5);
			while(rs.next())
			{
				Component comp = new Component();
				comp.setId(rs.getInt("id"));
				comp.setType(rs.getString("type"));
				comp.setPattern(rs.getString("pattern"));
				comp.setBrand(rs.getString("brand"));
				comp.setPrice(rs.getInt("price"));
				comp.setNum(rs.getInt("num"));
				comp.setSale(rs.getInt("sale"));
				list.add(comp);
			}
			request.setAttribute("result", list);
			if(String.valueOf(context.getAttribute("DifName")).equals("BOSS"))
			{
				System.out.println("1");
				request.getRequestDispatcher("/ComponentList.jsp").forward(request, response);
			}
			else
			{
				System.out.println("2");
				request.getRequestDispatcher("/BuyComponent.jsp").forward(request, response);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			JDBCUtils.release(rs, stmt, conn);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
